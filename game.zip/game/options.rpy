﻿## This file contains options that can be changed to customize your game.
##
## Lines beginning with two '#' marks are comments, and you shouldn't uncomment
## them. Lines beginning with a single '#' mark are commented-out code, and you
## may want to uncomment them when appropriate.


## Basics ######################################################################

## A human-readable name of the game. This is used to set the default window
## title, and shows up in the interface and error reports.
##
## The _() surrounding the string marks it as eligible for translation.

define config.name = _("Der Fluch von Scheuerhof")


## Deutsch ist die Standardsprache des Spiels (Original-Skript ist auf
## Deutsch geschrieben). Zusätzlich verfügbar: Englisch, Französisch,
## Luxemburgisch (siehe game/tl/).
define config.default_language = "german"


## Determines if the title given above is shown on the main menu screen. Set
## this to False to hide the title.

define gui.show_name = True


## The version of the game.

define config.version = "0.9.1"


## Text that is placed on the game's about screen. To insert a blank line
## between paragraphs, write \n\n.

define gui.about = _("""Eine Visual Novel über den Scheuerhof im Wald von Nohn.

Ersteller und Autor: Michael Klein

Bilder erstellt mit Flux2 Klein
Story ergänzt mit Unterstützung von Claude Code
Programmierung umgesetzt mit Unterstützung von Claude Code
Musik und Soundeffekte lokal generiert mit KI-Modellen (MusicGen und AudioLDM2)
Deutsche Sprachausgabe lokal generiert mit Piper (Stimmen: Thorsten-Voice, M-AILABS)

Die Geschichte enthält Elemente der realen Historie des Scheuerhofs. Namentliche Nennungen realer Personen und Firmen wurden aus Pietätsgründen geändert, um keine Persönlichkeitsrechte zu verletzen.""")


## A short name for the game used for executables and directories in the built
## distribution. This must be ASCII-only, and must not contain spaces, colons,
## or semicolons.

define build.name = "scheuerhof"

## Change the version used by the build system.
define build.version = "0.9.1"

## Sounds and music ############################################################

## These three variables control which mixers are shown to the player by
## default. Setting one of these to False will hide the appropriate mixer.

define config.has_sound = True
define config.has_music = True
## Die deutschen Dialoge sind vertont (siehe game/voice.rpy).
define config.has_voice = True
## Sprachausgabe muss in den Einstellungen bewusst aktiviert werden.
define config.default_voice_volume = 0.0


## To allow the user to play a test sound on the sound or voice channel,
## uncomment a line below and use it to set a sample sound to play.

# define config.sample_sound = "sample-sound.ogg"
# define config.sample_voice = "sample-voice.ogg"


## Uncomment the following line to set an audio file that will be played while
## the player is at the main menu. This file will continue playing into the
## game, until it is stopped or another file is played.

# define config.main_menu_music = "main-menu-theme.ogg"


## Transitions #################################################################
##
## These variables set transitions that are used when certain events occur.
## Each variable should be set to a transition, or None to indicate that no
## transition should be used.

## Entering or exiting the game menu.

define config.enter_transition = dissolve
define config.exit_transition = dissolve


## A transition that is used after a game has been loaded.

define config.after_load_transition = None


## Used when entering the main menu after the game has ended.

define config.end_game_transition = None


## A variable to set the transition used when the game starts does not exist.
## Instead, use a with statement after showing the initial scene.


## Window management ###########################################################
##
## This controls when the dialogue window is displayed. If "show", it is always
## displayed. If "hide", it is only displayed when dialogue is present. If
## "auto", the window is hidden before scene statements and shown again once
## dialogue is displayed.
##
## After the game has started, this can be changed with the "window show",
## "window hide", and "window auto" statements.

define config.window = "auto"


## Transitions used to show and hide the dialogue window

define config.window_show_transition = Dissolve(.2)
define config.window_hide_transition = Dissolve(.2)


## Preference defaults #########################################################

## Controls the default text speed. The default, 0, is infinite, while any other
## number is the number of characters per second to type out.

default preferences.text_cps = 0


## The default auto-forward delay. Larger numbers lead to longer waits, with 0
## to 30 being the valid range.

default preferences.afm_time = 15


## Save directory ##############################################################
##
## Controls the platform-specific place Ren'Py will place the save files for
## this game. The save files will be placed in:
##
## Windows: %APPDATA\RenPy\<config.save_directory>
##
## Macintosh: $HOME/Library/RenPy/<config.save_directory>
##
## Linux: $HOME/.renpy/<config.save_directory>
##
## This generally should not be changed, and if it is, should always be a
## literal string, not an expression.

## Bleibt bewusst auf 0.8: 0.9 fügt nur die Sprachausgabe hinzu, die
## Handlung ist unverändert. So finden Spielstände aus 0.8 sich weiter.
define config.save_directory = "scheuerhof-0.8"


## Icon ########################################################################
##
## The icon displayed on the taskbar or dock.

define config.window_icon = "gui/window_icon.png"


## Build configuration #########################################################
##
## This section controls how Ren'Py turns your project into distribution files.

init python:

    # SDK Fonts.
    config.searchpath.append(config.renpy_base + "/sdk-fonts")
    build.classify_renpy("sdk-fonts/**", "all")
    build._sdk_fonts = True

    ## The following functions take file patterns. File patterns are case-
    ## insensitive, and matched against the path relative to the base directory,
    ## with and without a leading /. If multiple patterns match, the first is
    ## used.
    ##
    ## In a pattern:
    ##
    ## / is the directory separator.
    ##
    ## * matches all characters, except the directory separator.
    ##
    ## ** matches all characters, including the directory separator.
    ##
    ## For example, "*.txt" matches txt files in the base directory, "game/
    ## **.ogg" matches ogg files in the game directory or any of its
    ## subdirectories, and "**.psd" matches psd files anywhere in the project.

    ## Classify files as None to exclude them from the built distributions.

    build.classify('**~', None)
    build.classify('**.bak', None)
    build.classify('**/.**', None)
    build.classify('**/#**', None)
    build.classify('**/thumbs.db', None)

    ## Der Projektordner enthält das Ren'Py-SDK, alte Build-Ausgaben und
    ## Log-Dateien als Geschwister von game/ - die gehören nicht ins Spiel.
    build.classify('renpy-*-sdk/**', None)
    build.classify('scheuerhof-*-dists/**', None)
    ## web_build erzeugt zusätzlich eine Zip-Kopie des Zielordners direkt im
    ## Projekt-Root (Geschwister der dists/-Mappe, kein Unterordner) - auch die
    ## gehört nicht ins Spiel.
    build.classify('scheuerhof-*-dists.zip', None)
    build.classify('errors.txt', None)
    build.classify('log.txt', None)

    ## tools/ enthält Python-Tooling zur Audio-Generierung (inkl. venvs mit
    ## Torch, mehrere GB) - gehört nicht in die Spiel-Distribution.
    build.classify('tools/**', None)

    ## valkyrie-quest/ ist ein unabhängiges VTT-Projekt, das zufällig als
    ## Geschwisterordner hier liegt - gehört ebenfalls nicht ins Spiel.
    build.classify('valkyrie-quest/**', None)

    ## To archive files, classify them as 'archive'.

    # build.classify('game/**.png', 'archive')
    # build.classify('game/**.jpg', 'archive')

    ## Files matching documentation patterns are duplicated in a mac app build,
    ## so they appear in both the app and the zip file.

    build.documentation('*.html')
    build.documentation('*.txt')

## A Google Play license key is required to download expansion files and perform
## in-app purchases. It can be found on the "Services & APIs" page of the Google
## Play developer console.

# define build.google_play_key = "..."


## The username and project name associated with an itch.io project, separated
## by a slash.

# define build.itch_project = "username/scheuerhof"


# Enable the console.
define config.console = True
